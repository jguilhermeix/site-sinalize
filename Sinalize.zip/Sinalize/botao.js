const botao = document.querySelector(".js theme");

botao.addEventListener("click", () => {
    console.log("botão pressionado")
})