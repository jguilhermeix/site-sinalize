document.getElementById("loginForm").addEventListener("submit", function (event) {
    event.preventDefault();

    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
    const errorMessage = document.getElementById("errorMessage");

    if (username === "admin" && password === "1234") {
        errorMessage.textContent = "";
        window.location.href = "index.html"
    } else {
        errorMessage.textContent = "Usuário ou senha incorretos.";
    }
});