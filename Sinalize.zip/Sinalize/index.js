const menu = document.querySelector(".menu");
const navMenu = document.querySelector(".nav-menu");
const lerMaisButton = document.querySelector('.Ler-Mais');
const textoOculto = document.querySelector('.texto-oculto');

menu.addEventListener("click", () => {
    menu.classList.toggle("active");
    navMenu.classList.toggle("active");
})

document.querySelectorAll(".nav-link").forEach(n => n.addEventListener("click", () => {
    menu.classList.remove("active")
    navMenu.classList.remove("active")
}))


lerMaisButton.addEventListener('click', () => {
    if (textoOculto.style.display === 'none') {
    textoOculto.style.display = 'block';
    lerMaisButton.textContent = 'Ler Menos';
    } else {
    textoOculto.style.display = 'none';
    lerMaisButton.textContent = 'Ler Mais';
    }
});